from .translator import makemydir
from .translator import machine_translator_df
from .translator import merge_csvs
from .translator import store_translation
from .translator import read_word_document
from .translator import save_text_to_docx
from .translator import replace_consecutive_chars
from .translator import machine_translator_doc
